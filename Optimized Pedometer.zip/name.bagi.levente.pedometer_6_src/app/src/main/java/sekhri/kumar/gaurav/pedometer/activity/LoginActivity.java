package sekhri.kumar.gaurav.pedometer.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import sekhri.kumar.gaurav.pedometer.Pedometer;
import sekhri.kumar.gaurav.pedometer.R;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void Login (View view){
        Intent intent = new Intent(getApplicationContext(), Pedometer.class);
        startActivity(intent);
    }

    public void MovetoSignup (View view){
        Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
        startActivity(intent);
    }
}
